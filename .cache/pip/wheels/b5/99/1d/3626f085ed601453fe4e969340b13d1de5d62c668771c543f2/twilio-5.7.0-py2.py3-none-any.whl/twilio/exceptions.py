# -*- coding: utf-8 -*-
class TwilioException(Exception):
    pass


class TwimlException(Exception):
    pass
