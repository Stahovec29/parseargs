# -*- coding: utf-8 -*-
__version__ = '0.0.1'


def _main():
    print("""
    =============================
    Frp NAT Downloader for Pyhton
    =============================

    pip install frp
    frp -h
    -----------------------------
    src: https://github.com/nat-cloud/frp
    -----------------------------
    """)