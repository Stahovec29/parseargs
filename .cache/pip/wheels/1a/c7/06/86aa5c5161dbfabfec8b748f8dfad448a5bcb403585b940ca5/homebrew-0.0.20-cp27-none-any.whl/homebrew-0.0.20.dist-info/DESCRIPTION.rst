===============================
homebrew
===============================

.. image:: https://img.shields.io/pypi/v/homebrew.svg
        :target: https://pypi.python.org/pypi/homebrew

.. image:: https://img.shields.io/travis/igroen/homebrew.svg
        :target: https://travis-ci.org/igroen/homebrew

.. image:: https://readthedocs.org/projects/homebrew-wrapper/badge/?version=latest
        :target: https://readthedocs.org/projects/homebrew-wrapper/?badge=latest
        :alt: Documentation Status

.. image:: https://coveralls.io/repos/igroen/homebrew/badge.svg?branch=master&service=github
        :target: https://coveralls.io/github/igroen/homebrew?branch=master

.. image:: https://codecov.io/github/igroen/homebrew/coverage.svg?branch=master
        :target: https://codecov.io/github/igroen/homebrew?branch=master

.. image:: https://requires.io/github/igroen/homebrew/requirements.svg?branch=master
        :target: https://requires.io/github/igroen/homebrew/requirements/?branch=master
        :alt: Requirements Status

Homebrew wrapper

* Free software: ISC license
* Documentation: https://homebrew-wrapper.readthedocs.org.

Features
--------

* Get overview of homebrew package dependencies

Credits
---------

Tools used in rendering this package:

*  Cookiecutter_
*  `cookiecutter-pypackage`_

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage




Changelog
---------

0.0.20 (2018-03-24)
-------------------

* Don't use universal wheel for python3 only package


